//get context 
(function() {
    'use strict'
    var audio_con;
    var ajax;
    var musicdata;

    window.AudioContext = window.AudioContext || window.webkitAudioContext;
    audio_con = new AudioContext();

    //get music file and change it to binary 
    ajax = new XMLHttpRequest();
    ajax.responseType = 'arraybuffer';
    ajax.open('GET','music/piano.wav',true);
    ajax.onload = function(){
        audio_con.decodeAudioData(ajax.response,function(temp){
            musicdata = temp;
        },
        function(error){
            alert(error.err);
        });
    };
    ajax.send();


    var frequencyRatioTempered;
    frequencyRatioTempered = 1.059463;
    var keyboards;
    keyboards = Array.prototype.slice.call(document.getElementById('keyboard'));
    keyboards.reverse().map(function(keyboard, index) {
        var i, frequencyRatio;
        frequencyRatio = 1;
        for (i = 0; i < index; i++) {
            frequencyRatio /= frequencyRatioTempered;
        }
        keyboard.addEventListener('click', function() {
            var bufferSource;
            bufferSource = audio_con.createBufferSource();
            bufferSource.buffer = musicdata;
            bufferSource.connect(audio_con.destination);
            bufferSource.playbackRate.value = frequencyRatio;
            bufferSource.start(0);
        });
    });
})();